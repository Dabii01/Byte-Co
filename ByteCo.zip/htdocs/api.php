<?php
declare(strict_types=1);
require_once __DIR__.'/push.php';
ini_set('session.use_strict_mode','1');
// Some shared hosts expose TLS through SERVER_PORT rather than HTTPS.
$secure=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')
 || (int)($_SERVER['SERVER_PORT']??0)===443;
$local=in_array($_SERVER['HTTP_HOST']??'',['localhost:8080','127.0.0.1:8080'],true);
if(!$secure&&!$local){
 header('Content-Type: application/json; charset=utf-8');
 header('Cache-Control: no-store');
 http_response_code(400);
 echo json_encode(['error'=>'Please open https://byteco.ct.ws/ and sign in again.']);
 exit;
}
session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax','path'=>'/']);
session_start();
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
function out(array $body,int $code=200):never{http_response_code($code);echo json_encode($body,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);exit;}
function fail(string $message,int $code=400):never{out(['error'=>$message],$code);}
function csrf():string{return $_SESSION['csrf']??=bin2hex(random_bytes(32));}
function cleanUser(array $u):array{return ['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email'],'username'=>$u['username'],'role'=>$u['role'],'team'=>$u['team'],'mustChange'=>(bool)$u['must_change'],'active'=>(bool)$u['active']];}
function scope(array $data,array $u):array{
 if($u['role']==='Head')return $data;
 $data['briefs']=array_values(array_filter($data['briefs'],fn($b)=>$u['role']==='Team leader'?$b['team']===$u['team']:$b['editor']===$u['name']));
 $ids=array_column($data['briefs'],'id');$invoices=[];
 foreach($data['invoices'] as $i){$i['ids']=array_values(array_intersect($i['ids'],$ids));if($i['ids'])$invoices[]=$i;}$data['invoices']=$invoices;return $data;
}
function accountCreateScope(array $u,string $role,string $team):string {
 if($u['role']==='Head')return $team;
 if($u['role']!=='Team leader'||$role!=='Editor')fail('Team leaders can create Editor accounts only.',403);
 if(trim((string)($u['team']??''))==='')fail('Your account needs a team before creating editors.',403);
 if($team!==$u['team'])fail('You can only create editors for your own team.',403);
 return $u['team'];
}
function validReviewUrl($value):bool {
 return is_string($value)&&filter_var($value,FILTER_VALIDATE_URL)!==false&&in_array(strtolower(parse_url($value,PHP_URL_SCHEME)??''),['http','https'],true);
}
function reviewWorkflow(array $b,?array $old,array $u):array {
 $resubmit=($b['resubmitForApproval']??false)===true;unset($b['resubmitForApproval']);
 $incomingFeedback=trim((string)($b['feedback']??''));
 $previous=$old['approvalStatus']??'Not submitted';
 $requested=$b['approvalStatus']??$previous;
 $b['link']=trim((string)($b['link']??''));$b['finalLink']=trim((string)($b['finalLink']??''));
 $both=validReviewUrl($b['link'])&&validReviewUrl($b['finalLink']);
 $linksChanged=$b['link']!==($old['link']??'')||$b['finalLink']!==($old['finalLink']??'');
 $undo=$previous==='Approved'&&$requested==='Pending review';
 if($undo&&!$resubmit&&$u['role']!=='Team leader')fail('Only the assigned team leader can undo approval.',403);
 $decision=$u['role']==='Team leader'&&$requested!==$previous&&in_array($requested,['Approved','Changes requested'],true);
 if($u['role']!=='Team leader'&&$requested!==$previous&&in_array($requested,['Approved','Changes requested'],true))fail('Only the assigned team leader can approve submitted videos or request changes.',403);
 // Never trust review metadata or approval status sent by members.
 foreach(['submittedAt','lastSubmittedAt','reviewedAt','reviewedBy','feedback'] as $field){if(array_key_exists($field,$old??[]))$b[$field]=$old[$field];else unset($b[$field]);}
 $b['approvalStatus']=$previous;
 if(!isset($b['lastSubmittedAt'])&&isset($old['submittedAt']))$b['lastSubmittedAt']=$old['submittedAt'];
 if($resubmit){
  if($u['role']!=='Editor'||($b['editor']??'')!==$u['name']||($old&&($old['editor']??'')!==$u['name']))fail('Only the assigned editor can resubmit this brief.',403);
  if(!$both)fail('Review Link and Final Link are required.');
  if($previous==='Pending review')fail('This brief is already awaiting review.',409);
  $b['approvalStatus']='Pending review';$b['submittedAt']=gmdate('c');$b['lastSubmittedAt']=$b['submittedAt'];
  unset($b['reviewedAt'],$b['reviewedBy']);
 }elseif($undo){
  if(($old['team']??'')!==($u['team']??'')||($b['team']??'')!==($u['team']??''))fail('You can only review your own team.',403);
  if(!$both||$linksChanged)fail('Reopen the current approved links before editing them.',409);
  $b['approvalStatus']='Pending review';
  unset($b['reviewedAt'],$b['reviewedBy'],$b['feedback']);
 }elseif($decision){
  if(($old['team']??'')!==($u['team']??'')||($b['team']??'')!==($u['team']??''))fail('You can only review your own team.',403);
  if($previous!=='Pending review'||!$both||$linksChanged)fail('Review the current submitted links before making a decision.',409);
  $b['approvalStatus']=$requested;$b['reviewedAt']=gmdate('c');$b['reviewedBy']=$u['name'];
  $b['feedback']=$incomingFeedback;
  if($requested==='Changes requested'&&$b['feedback']==='')fail('Feedback is required when requesting changes.');
 }elseif(!$both||$linksChanged||($b['naming']??'')!==($old['naming']??'')){
  $b['approvalStatus']='Not submitted';unset($b['submittedAt'],$b['reviewedAt'],$b['reviewedBy']);
 }
 return $b;
}

try{
 if(!is_file(__DIR__.'/config.php'))fail('Installation needed. Copy config.example.php to config.php and enter your MySQL details.',503);
 $c=require __DIR__.'/config.php';$db=new PDO('mysql:host='.$c['host'].';dbname='.$c['database'].';charset=utf8mb4',$c['username'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 $action=$_GET['action']??'me';$method=$_SERVER['REQUEST_METHOD'];
 if($method!=='GET'&&!hash_equals(csrf(),$_SERVER['HTTP_X_CSRF_TOKEN']??''))fail('Session expired. Refresh the page and retry.',403);
 $raw=file_get_contents('php://input');if(strlen($raw)>2000000)fail('Request is too large.');$input=$raw!==''?json_decode($raw,true,512,JSON_THROW_ON_ERROR):[];
 if($action==='install'){
  if($method==='GET')out(['csrf'=>csrf()]);
  if($method!=='POST')fail('Method not allowed.',405);
  $db->exec("CREATE TABLE IF NOT EXISTS byte_users (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL UNIQUE,email VARCHAR(190) NOT NULL UNIQUE,username VARCHAR(100) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,role VARCHAR(30) NOT NULL,team VARCHAR(100) NOT NULL DEFAULT '',must_change TINYINT NOT NULL DEFAULT 1,active TINYINT NOT NULL DEFAULT 1,session_version INT NOT NULL DEFAULT 1)");
  $db->exec("CREATE TABLE IF NOT EXISTS byte_workspace (id INT PRIMARY KEY,data LONGTEXT NOT NULL,revision INT NOT NULL DEFAULT 0)");
  $db->exec("CREATE TABLE IF NOT EXISTS byte_attempts (id VARCHAR(64) PRIMARY KEY,attempts INT NOT NULL DEFAULT 0,started BIGINT NOT NULL)");
  if((int)$db->query('SELECT COUNT(*) FROM byte_users')->fetchColumn()>0)fail('Already installed.',409);
  if(!is_file(__DIR__.'/seed.php'))fail('Missing installation seed.');$seed=require __DIR__.'/seed.php';
  $installPassword=(string)($input['password']??'');
  $setupKey=trim((string)($input['setupKey']??''));
  if(empty($seed['bootstrap_salt'])||empty($seed['bootstrap_verifier'])||($seed['setup_version']??0)!==3)fail('Replace all three setup files from the new ZIP.',409);
  $check=hash_pbkdf2('sha256',$setupKey,$seed['bootstrap_salt'],210000,64,false);
  if(!hash_equals($seed['bootstrap_verifier'],$check))fail('The setup key does not match. Copy it from SETUP_KEY.txt in your downloaded ZIP.',403);
  if(strlen($installPassword)<12||strlen($installPassword)>72)fail('Choose a new password of 12–72 characters.');
  $nativeHash=password_hash($installPassword,PASSWORD_DEFAULT);
  if(!password_verify($installPassword,$nativeHash))fail('Server password hashing failed. No account was created.',500);
  $db->prepare('INSERT INTO byte_users (name,email,username,password_hash,role,team,must_change) VALUES (?,?,?,?,?,?,0)')->execute([$seed['name'],$seed['email'],$seed['username'],$nativeHash,'Head','']);
  $db->prepare('INSERT IGNORE INTO byte_workspace(id,data,revision) VALUES(1,?,0)')->execute([json_encode(['briefs'=>[],'invoices'=>[]])]);
  @unlink(__DIR__.'/seed.php');out(['installed'=>true]);
 }
 $u=null;
 if(isset($_SESSION['uid'])&&time()-($_SESSION['last']??0)<28800){$q=$db->prepare('SELECT * FROM byte_users WHERE id=? AND active=1');$q->execute([$_SESSION['uid']]);$u=$q->fetch()?:null;if($u&&$u['session_version']!=($_SESSION['version']??0))$u=null;}
 if($u)$_SESSION['last']=time();
 if($action==='me'&&$method==='GET')out(['user'=>$u?cleanUser($u):null,'csrf'=>csrf()]);
 if($action==='login'&&$method==='POST'){
  $key=hash('sha256',$_SERVER['REMOTE_ADDR']??'');$now=time();
  $db->prepare('INSERT INTO byte_attempts(id,attempts,started) VALUES(?,1,?) ON DUPLICATE KEY UPDATE attempts=IF(started<? ,1,attempts+1),started=IF(started<? ,?,started)')->execute([$key,$now,$now-900,$now-900,$now]);
  $q=$db->prepare('SELECT attempts FROM byte_attempts WHERE id=?');$q->execute([$key]);if((int)$q->fetchColumn()>10)fail('Too many attempts. Try again in 15 minutes.',429);
  $id=trim((string)($input['login']??''));$q=$db->prepare('SELECT * FROM byte_users WHERE (email=? OR username=?) AND active=1 LIMIT 1');$q->execute([$id,$id]);$u=$q->fetch();
  if(!$u||!password_verify((string)($input['password']??''),$u['password_hash']))fail('Incorrect login or password.',401);
  $db->prepare('DELETE FROM byte_attempts WHERE id=?')->execute([$key]);session_regenerate_id(true);$_SESSION=['uid'=>$u['id'],'version'=>$u['session_version'],'last'=>time(),'csrf'=>bin2hex(random_bytes(32))];out(['user'=>cleanUser($u),'csrf'=>csrf()]);
 }
 if(!$u)fail('Please sign in.',401);
 if($action==='logout'&&$method==='POST'){if(isset($_SESSION['push_endpoint_hash'])){try{$db->prepare('DELETE FROM byte_push_devices WHERE endpoint_hash=? AND user_id=?')->execute([$_SESSION['push_endpoint_hash'],$u['id']]);}catch(Throwable $e){}}$_SESSION=[];session_destroy();out(['ok'=>true]);}
 if($action==='password'&&$method==='POST'){
  if(!password_verify((string)($input['current']??''),$u['password_hash']))fail('Current password is incorrect.');$password=(string)($input['password']??'');
  if(strlen($password)<12||strlen($password)>72)fail('Use 12–72 characters.');if(password_verify($password,$u['password_hash']))fail('Choose a different password.');
  $db->prepare('UPDATE byte_users SET password_hash=?,must_change=0,session_version=session_version+1 WHERE id=?')->execute([password_hash($password,PASSWORD_DEFAULT),$u['id']]);$_SESSION['version']=(int)$u['session_version']+1;session_regenerate_id(true);$u['must_change']=0;out(['user'=>cleanUser($u)]);
 }
 if($u['must_change'])fail('Change your temporary password first.',403);
 if(in_array($action,['notion-auto-setup','notion-auto-status','notion-auto-disable','notion-auto-pull'],true)){require_once __DIR__.'/notion-sync.php';notionAuto($db,$u,$action,$method,$input);}
 if(in_array($action,['notion-test','notion-preview','notion-import'],true)){require_once __DIR__.'/notion-import.php';handleNotion($db,$u,$action,$method,$input);}
 if(in_array($action,['push-options','push-subscription','push-test'],true)){
  try{$pushKeys=pushKeys($db);}catch(Throwable $e){fail($e->getMessage(),503);}
  if($action==='push-options'&&$method==='GET')out(['publicKey'=>$pushKeys['public_key']]);
  if($method!=='POST')fail('Method not allowed.',405);
  if($action==='push-test'){
   if(time()-($_SESSION['push_test_at']??0)<30)fail('Wait 30 seconds before sending another test.',429);$_SESSION['push_test_at']=time();
   $endpoint=(string)($input['endpoint']??'');if(!pushEndpoint($endpoint))fail('Enable push on this device before testing.');$result=pushSend($db,[(int)$u['id']],$endpoint);if(!$result['sent'])fail('Push diagnostic: '.implode(' ',array_unique($result['errors']?:['No device accepted the request.'])),503);out($result);
  }
  $endpoint=(string)($input['endpoint']??'');if(!pushEndpoint($endpoint))fail('This browser push endpoint is not supported.');$hash=hash('sha256',$endpoint);
  if(($input['operation']??'')==='remove')$db->prepare('DELETE FROM byte_push_devices WHERE endpoint_hash=? AND user_id=?')->execute([$hash,$u['id']]);
  else{$db->prepare('INSERT INTO byte_push_devices(endpoint_hash,user_id,endpoint,updated_at) VALUES(?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),endpoint=VALUES(endpoint),updated_at=UTC_TIMESTAMP()')->execute([$hash,$u['id'],$endpoint]);$_SESSION['push_endpoint_hash']=$hash;}
  out(['ok'=>true]);
 }
 if($action==='shared-views'){
  $db->exec('CREATE TABLE IF NOT EXISTS byte_shared_views (name VARCHAR(80) PRIMARY KEY,config LONGTEXT NOT NULL,revision INT NOT NULL DEFAULT 1,updated_by INT NOT NULL,updated_at DATETIME NOT NULL)');
  $readViews=function()use($db){$rows=$db->query('SELECT name,config,revision FROM byte_shared_views ORDER BY name')->fetchAll();foreach($rows as &$v){$v['config']=json_decode($v['config'],true,512,JSON_THROW_ON_ERROR);$v['revision']=(int)$v['revision'];}return $rows;};
  if($method==='GET')out(['views'=>$readViews()]);
  if($method!=='POST')fail('Method not allowed.',405);
  if(!in_array($u['role'],['Head','Team leader'],true))fail('Only team leaders and Head can save shared views.',403);
  $name=trim((string)($input['name']??''));$cfg=$input['config']??null;
  $fields=['id','brand','product','status','progress','approvalStatus','format','editor','strategist','due','link','finalLink','type','problem','persona','awareness','mechanism','winner','adResult','naming','delivery'];
  if(!$name||strlen($name)>80||!is_array($cfg)||strlen(json_encode($cfg))>20000)fail('Invalid view.');
  if(!in_array($cfg['baseView']??'',['All briefs','My briefs','Allaura','The Fleece Company','Submitted','Archive'],true)||!in_array($cfg['sort']??'',['default','title','due'],true)||!in_array($cfg['mode']??'',['AND','OR'],true))fail('Invalid view settings.');
  foreach(['visible','order'] as $field){if(!is_array($cfg[$field]??null)||count($cfg[$field])>30||array_diff($cfg[$field],$fields))fail('Invalid columns.');}
  if(!is_array($cfg['widths']??null)||count($cfg['widths'])>30)fail('Invalid widths.');foreach($cfg['widths'] as $key=>$width)if(!in_array($key,$fields,true)||!is_numeric($width)||$width<100||$width>650)fail('Invalid column width.');
  foreach(['filter','strategist','winner','adResult'] as $field)if(!is_string($cfg[$field]??null)||strlen($cfg[$field])>150)fail('Invalid filter.');
  if(!is_array($cfg['statuses']??null)||count($cfg['statuses'])>30||!is_array($cfg['rules']??null)||count($cfg['rules'])>20)fail('Invalid filters.');foreach($cfg['statuses'] as $status)if(!is_string($status)||strlen($status)>100)fail('Invalid status.');
  foreach($cfg['rules'] as $rule)if(!is_array($rule)||!in_array($rule['field']??'',$fields,true)||!in_array($rule['op']??'',['is','is not','contains','is any'],true)||!is_string($rule['value']??null)||strlen($rule['value'])>150)fail('Invalid advanced filter.');
  $revision=(int)($input['revision']??0);$json=json_encode($cfg,JSON_THROW_ON_ERROR);
  if($revision===0){try{$db->prepare('INSERT INTO byte_shared_views(name,config,updated_by,updated_at) VALUES(?,?,?,UTC_TIMESTAMP())')->execute([$name,$json,$u['id']]);}catch(PDOException $e){if($e->getCode()==='23000')fail('This view already exists. Refresh and retry.',409);throw $e;}}
  else{$q=$db->prepare('UPDATE byte_shared_views SET config=?,revision=revision+1,updated_by=?,updated_at=UTC_TIMESTAMP() WHERE name=? AND revision=?');$q->execute([$json,$u['id'],$name,$revision]);if(!$q->rowCount())fail('Another leader changed this view. Refresh before saving.',409);}
  out(['views'=>$readViews()]);
 }
 if($action==='notification-reads'){
  $db->exec("CREATE TABLE IF NOT EXISTS byte_notification_reads (user_id INT NOT NULL,notification_hash CHAR(64) NOT NULL,notification_id TEXT NOT NULL,read_at DATETIME NOT NULL,PRIMARY KEY(user_id,notification_hash))");
  if($method==='GET'){$q=$db->prepare('SELECT notification_id FROM byte_notification_reads WHERE user_id=?');$q->execute([$u['id']]);out(['ids'=>$q->fetchAll(PDO::FETCH_COLUMN)]);}
  if($method!=='POST')fail('Method not allowed.',405);
  $ids=$input['ids']??null;if(!is_array($ids)||count($ids)>1000)fail('Invalid notifications.');
  foreach($ids as $id)if(!is_string($id)||strlen($id)>1500)fail('Invalid notification.');
  $q=$db->prepare('INSERT INTO byte_notification_reads(user_id,notification_hash,notification_id,read_at) VALUES(?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE read_at=UTC_TIMESTAMP()');
  foreach($ids as $id)$q->execute([$u['id'],hash('sha256',$id),$id]);out(['ok'=>true]);
 }
 if($action==='users'){
  if(!in_array($u['role'],['Head','Team leader'],true))fail('Account access denied.',403);
  if($method==='GET'){if($u['role']==='Head')$rows=$db->query('SELECT * FROM byte_users ORDER BY name')->fetchAll();else{$q=$db->prepare("SELECT * FROM byte_users WHERE role='Editor' AND team=? ORDER BY name");$q->execute([$u['team']]);$rows=$q->fetchAll();}out(['users'=>array_map('cleanUser',$rows)]);}
  if($method!=='POST')fail('Method not allowed.',405);
  if(($input['operation']??'')==='edit'){require_once __DIR__.'/account-edit.php';editAccount($db,$u,$input);}
  if(($input['operation']??'')==='create'){
   $name=trim((string)($input['name']??''));$email=strtolower(trim((string)($input['email']??'')));$username=trim((string)($input['username']??''));$role=$input['role']??'';$team=trim((string)($input['team']??''));$password=(string)($input['password']??'');
   $team=accountCreateScope($u,(string)$role,$team);
   if(!$name||strlen($name)>100||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190||!preg_match('/^[a-zA-Z0-9_.-]{3,100}$/',$username)||!in_array($role,['Head','Team leader','Editor'],true)||($role!=='Head'&&!$team)||strlen($team)>100||strlen($password)<12||strlen($password)>72)fail('Check the name, email, username, team and password (12–72 characters).');
   $db->prepare('INSERT INTO byte_users(name,email,username,password_hash,role,team,must_change) VALUES(?,?,?,?,?,?,1)')->execute([$name,$email,$username,password_hash($password,PASSWORD_DEFAULT),$role,$team]);out(['ok'=>true]);
  }
  if($u['role']!=='Head')fail('Only the head account can reset passwords or disable accounts.',403);
  $id=(int)($input['id']??0);if($id===(int)$u['id'])fail('Use Change password for your own account.');
  if(($input['operation']??'')==='reset'){$password=(string)($input['password']??'');if(strlen($password)<12||strlen($password)>72)fail('Use 12–72 characters.');$db->prepare('UPDATE byte_users SET password_hash=?,must_change=1,session_version=session_version+1 WHERE id=?')->execute([password_hash($password,PASSWORD_DEFAULT),$id]);}
  elseif(($input['operation']??'')==='toggle')$db->prepare('UPDATE byte_users SET active=1-active,session_version=session_version+1 WHERE id=?')->execute([$id]);else fail('Unknown account action.');out(['ok'=>true]);
 }
 if($action!=='workspace')fail('Not found.',404);
 $q=$db->query('SELECT * FROM byte_workspace WHERE id=1');$row=$q->fetch();$data=json_decode($row['data'],true,512,JSON_THROW_ON_ERROR);
 $people=$db->query("SELECT name,username,role,team FROM byte_users WHERE active=1 ORDER BY name")->fetchAll();if($u['role']!=='Head')$people=array_values(array_filter($people,fn($p)=>$p['team']===$u['team']));
 if($method==='GET')out(['data'=>scope($data,$u),'revision'=>(int)$row['revision'],'people'=>$people]);
 if($method!=='PUT')fail('Method not allowed.',405);
 if(($input['revision']??-1)!=(int)$row['revision'])fail('Another update was saved. Refresh and retry.',409);
 $next=$input['data']??null;if(!is_array($next)||!is_array($next['briefs']??null)||!is_array($next['invoices']??null))fail('Invalid workspace.');
 $visible=scope($data,$u);$oldBy=[];foreach($data['briefs'] as $b)$oldBy[$b['id']]=$b;$visibleIds=array_column($visible['briefs'],'id');$result=[];$seen=[];
 foreach($next['briefs'] as $b){
  if(!is_array($b))fail('Invalid brief.');$id=$b['id']??'';$prior=$b['previousId']??$id;
  if(!is_string($id)||!preg_match('/^.{1,80}$/u',$id)||in_array($id,$seen,true))fail('Concept IDs must be unique and 1–80 characters.');$seen[]=$id;
  if(isset($oldBy[$id])&&$prior!==$id)fail('Concept ID already exists.');$old=$oldBy[$prior]??null;
  if($old&&!in_array($prior,$visibleIds,true))fail('Brief access denied.',403);
  if($old&&$old==$b){$result[]=$old;continue;}
  if(!$old&&isset($oldBy[$id]))fail('Concept ID already exists.');
  if($u['role']!=='Head'){
   if($u['role']==='Editor'){$b['editor']=$u['name'];$b['team']=$u['team'];}
   else {if(($b['team']??'')!==$u['team'])fail('You can only change your own team.',403);$names=array_column($people,'name');if(!in_array($b['editor']??'', $names,true))fail('Assignee must be in your team.');}
  }
  if(!in_array($b['editor']??'',array_column($people,'name'),true))fail('Create an active account for the assignee before assigning a brief.');
  if(!in_array($b['brand']??'', ['Allaura','The Fleece Company'],true)||!in_array($b['type']??'', ['Video','VideoShorter'],true))fail('Invalid brand or type.');
  if($b['brand']==='Allaura')$b['product']='';
  if(isset($b['progress'])&&(!is_int($b['progress'])||$b['progress']<0||$b['progress']>100))fail('Progress must be 0–100.');
  if($old&&isset($old['notionPageId'])){$b['notionPageId']=$old['notionPageId'];$b['notion']=$old['notion']??'';foreach(['notionBaseline','notionLatestContent','notionSyncWarning','notionEditedAt'] as $field){if(array_key_exists($field,$old))$b[$field]=$old[$field];else unset($b[$field]);}}
  $b=reviewWorkflow($b,$old,$u);
  foreach($data['invoices'] as $invoice){if(in_array($prior,$invoice['ids'],true)&&$old!=$b)fail('Invoiced briefs are locked.',403);}
  $b['createdBy']=$old['createdBy']??$u['name'];$b['createdAt']=$old['createdAt']??gmdate('c');if(!$old||$old!=$b){$b['updatedAt']=gmdate('c');$b['updatedBy']=$u['name'];}$b['previousId']=null;unset($b['previousId']);$result[]=$b;
 }
 foreach($visible['briefs'] as $b)if(!in_array($b['id'],$seen,true)&&!in_array($b['id'],array_column($next['briefs'],'previousId'),true))fail('Use Archive or Trash instead of permanently deleting a brief.');
 foreach($data['briefs'] as $b)if(!in_array($b['id'],$visibleIds,true)){$result[]=$b;}
 $invoices=$data['invoices'];
 if($u['role']==='Head')$invoices=$next['invoices'];
 elseif($u['role']==='Team leader'){
  foreach($next['invoices'] as $invoice){$old=null;foreach($data['invoices'] as $i)if($i['id']===$invoice['id'])$old=$i;if($old){if($old!=$invoice)fail('Only Head can change invoice payment status.',403);continue;}
   if(($invoice['team']??'')!==$u['team']||($invoice['status']??'')!=='Submitted')fail('Invalid invoice.');foreach($invoice['ids'] as $bid){$candidate=null;foreach($result as $b)if($b['id']===$bid)$candidate=$b;if(!$candidate||$candidate['team']!==$u['team']||($candidate['approvalStatus']??'')!=='Approved')fail('Invoice must contain approved team briefs.');foreach($invoices as $i)if(in_array($bid,$i['ids'],true))fail('Brief already invoiced.');}$invoices[]=$invoice;
  }
 }elseif($next['invoices']!=$visible['invoices'])fail('Editors cannot change invoices.',403);
 foreach($invoices as &$invoice){$oldInvoice=null;foreach($data['invoices'] as $priorInvoice)if($priorInvoice['id']===$invoice['id']){$oldInvoice=$priorInvoice;break;}if(!$oldInvoice||($oldInvoice['status']??'')!==($invoice['status']??''))$invoice['updatedAt']=gmdate('c');else{if(isset($oldInvoice['updatedAt']))$invoice['updatedAt']=$oldInvoice['updatedAt'];else unset($invoice['updatedAt']);}}unset($invoice);
 $updated=['briefs'=>$result,'invoices'=>$invoices];$q=$db->prepare('UPDATE byte_workspace SET data=?,revision=revision+1 WHERE id=1 AND revision=?');$q->execute([json_encode($updated,JSON_THROW_ON_ERROR),(int)$row['revision']]);if(!$q->rowCount())fail('Another update was saved. Refresh and retry.',409);$pushUsers=$db->query('SELECT id,name,role,team,active FROM byte_users WHERE active=1')->fetchAll();pushSend($db,pushRecipients($data,$updated,$pushUsers,(int)$u['id']));out(['data'=>scope($updated,$u),'revision'=>(int)$row['revision']+1]);
}catch(PDOException $e){if($e->getCode()==='23000')fail('That name, email or username is already in use.',409);fail('Database not ready. Check config.php, then run installation.',503);}catch(Throwable $e){fail('The request could not be completed.',500);}

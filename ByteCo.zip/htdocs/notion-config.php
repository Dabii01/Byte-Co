<?php
// Copy this file to notion-config.php. Enter your token ONLY on your server.
// Keep config.php (your MySQL details) unchanged.
return [
 'token' => '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',
 'sources' => [
  'The Fleece Company' => 'cf5a4eb3480b821085a601e42a909321',
  'Allaura' => '348a4eb3480b801d814cd534a838f1cf',
 ],
];

<?php
declare(strict_types=1);
require_once __DIR__.'/notion-import.php';
function notionSyncSchema(PDO $db):void{$db->exec("CREATE TABLE IF NOT EXISTS byte_notion_editor_jobs (source_id VARCHAR(36) NOT NULL,user_id INT NOT NULL,`cursor` TEXT NULL,watermark VARCHAR(40) NULL,scan_started VARCHAR(40) NULL,next_run BIGINT NOT NULL DEFAULT 0,last_message VARCHAR(250) NOT NULL DEFAULT '',PRIMARY KEY(source_id,user_id))");$db->exec('CREATE TABLE IF NOT EXISTS byte_notion_sync (source_id VARCHAR(36) PRIMARY KEY,brand VARCHAR(40) NOT NULL,settings LONGTEXT NOT NULL,`cursor` TEXT NULL,watermark VARCHAR(40) NULL,scan_started VARCHAR(40) NULL,next_run BIGINT NOT NULL DEFAULT 0,last_message VARCHAR(250) NOT NULL DEFAULT \'\',enabled TINYINT NOT NULL DEFAULT 1)');}
function notionKey(string $s):string{return strtolower(trim(preg_replace('/\s+/u',' ',$s)));}
function notionBaselineFor(array $b):array{return ['_blocksHash'=>hash('sha256',json_encode($b['blocks']??[],JSON_THROW_ON_ERROR))]+array_intersect_key($b,array_flip(['product','format','strategist','persona','problem','due','awareness','mechanism','winner','adResult','type','editor','team','content']));}
function notionMerge(array $old,array $incoming):array{
 $baseline=$old['notionBaseline']??[];$conflicts=[];
 // Work-state fields are exclusively managed in Byte Co. after the first import.
 foreach(['product','format','strategist','persona','problem','due','awareness','mechanism','winner','adResult','type'] as $field){if(array_key_exists($field,$baseline)&&($old[$field]??'')===$baseline[$field])$old[$field]=$incoming[$field]??'';}
 if(isset($baseline['editor'])&&($old['editor']??'')===$baseline['editor']){$old['editor']=$incoming['editor'];$old['team']=$incoming['team'];}
 if(array_key_exists('content',$baseline)&&($old['content']??'')===$baseline['content']&&($baseline['_blocksHash']??'')===hash('sha256',json_encode($old['blocks']??[],JSON_THROW_ON_ERROR))){$old['content']=$incoming['content'];$old['blocks']=$incoming['blocks'];}
 elseif(($old['content']??'')!==$incoming['content'])$conflicts[]='The Notion brief text changed. Your website text was kept.';
 $old['notionBaseline']=notionBaselineFor($incoming);$old['notionLatestContent']=$incoming['content'];$old['notionSyncWarning']=implode(' ',$conflicts);return $old;
}
function notionAssignedFilter(string $property,array $ids,?string $watermark):array{
 $conditions=[];if($watermark)$conditions[]=['timestamp'=>'last_edited_time','last_edited_time'=>['on_or_after'=>$watermark]];
 if($ids){$filters=array_map(fn($id)=>['property'=>$property,'people'=>['contains'=>$id]],array_values(array_unique($ids)));$conditions[]=count($filters)===1?$filters[0]:['or'=>$filters];}
 return count($conditions)===1?$conditions[0]:($conditions?['and'=>$conditions]:[]);
}
function notionTeamSettings(array $actor,array $prior,array $incoming,array $allAccounts):array{
 if($actor['role']==='Head')return $incoming;
 if($actor['role']!=='Team leader')fail('Team leader access required.',403);
 if(isset($prior['mapping'])&&$prior['mapping']!=$incoming['mapping'])fail('The shared field mapping is managed by Head. Keep its current mapping.',403);
 foreach($incoming['editorAliases'] as $raw=>$target){$targetMatch=notionAccountMatch($target,$allAccounts);$priorMatch=notionAccountMatch($raw,$allAccounts,$prior['editorAliases']??[]);if(!$targetMatch||$targetMatch['team']!==$actor['team']||($priorMatch&&$priorMatch['team']!==$actor['team']))fail('You can only bind Notion assignees to your own team.',403);}
 foreach($incoming['typeAliases'] as $raw=>$type)if(isset($prior['typeAliases'][$raw])&&$prior['typeAliases'][$raw]!==$type)fail('Ask Head to change shared video-type mappings.',403);
 return $incoming;
}
function notionAuto(PDO $db,array $u,string $action,string $method,array $input):never{
 if($method!=='POST')fail('Method not allowed.',405);
 try{
 notionSyncSchema($db);
 if($action==='notion-auto-setup'){
  if(!in_array($u['role'],['Head','Team leader'],true))fail('Only Head and team leaders can enable Notion sync.',403);
  $brand=(string)($input['brand']??'');$source=(string)($input['source']??'');$preview=$_SESSION['notion_preview']??[];
  if(($preview['brand']??'')!==$brand||($preview['source']??'')!==$source||($preview['expires']??0)<time()||!hash_equals($preview['batch']??'',(string)($input['batch']??'')))fail('Load a fresh preview before enabling automatic sync.');
  $map=$input['mapping']??[];if(!is_array($map)||count($map)>25||empty($map['id'])||empty($map['editor']))fail('Map Concept ID and Assignee first.');foreach($map as $value)if(!is_string($value)||strlen($value)>200)fail('Invalid mapping.');
  $q=$db->query("SELECT name,username,team FROM byte_users WHERE active=1 AND role='Editor'");$allAccounts=$q->fetchAll();$accounts=$u['role']==='Team leader'?array_values(array_filter($allAccounts,fn($a)=>$a['team']===$u['team'])):$allAccounts;$names=array_column($accounts,'name');$editorAliases=[];$typeAliases=[];$notionPeople=[];$selectedEditors=$input['editors']??[];$selectedTypes=$input['types']??[];if(!is_array($selectedEditors)||!is_array($selectedTypes))fail('Invalid account mappings.');
  foreach($preview['pages'] as $id=>$page){$p=$page['properties'];$raw=notionValue($p[$map['editor']]??[]);if($raw!==''&&($p[$map['editor']]['type']??'')==='people')$notionPeople[notionKey($raw)]=array_column($p[$map['editor']]['people']??[],'id');$chosen=$selectedEditors[$id]??'';if($chosen!==''&&!in_array($chosen,$names,true))fail('Choose an active Editor account.');if($raw!==''&&$chosen!==''){$key=notionKey($raw);if(isset($editorAliases[$key])&&$editorAliases[$key]!==$chosen)fail('One Notion assignee is mapped to different editors. Use one matching account.');$editorAliases[$key]=$chosen;}$rawType=notionValue($p[$map['type']??'']??[]);$type=$selectedTypes[$id]??'';if(in_array($type,['Video','VideoShorter'],true)&&$rawType!=='')$typeAliases[notionKey($rawType)]=$type;}
  $bindings=$input['bindings']??[];if(!is_array($bindings)||count($bindings)>100)fail('Invalid assignee bindings.');foreach($bindings as $raw=>$name){if(!is_string($raw)||strlen($raw)>150||!is_string($name))fail('Invalid assignee binding.');if($name==='')continue;if(!in_array($name,$names,true))fail('Binding must use an active Editor account.');$editorAliases[notionKey($raw)]=$name;}
  $settings=['mapping'=>$map,'editorAliases'=>$editorAliases,'typeAliases'=>$typeAliases,'notionPeople'=>$notionPeople];
  // Keep previously confirmed aliases when enabling from another preview page.
  $q=$db->prepare('SELECT settings FROM byte_notion_sync WHERE source_id=?');$q->execute([$source]);$prior=json_decode($q->fetchColumn()?:'{}',true);$settings=notionTeamSettings($u,$prior,$settings,$allAccounts);foreach(['editorAliases','typeAliases','notionPeople'] as $field)$settings[$field]=array_merge($prior[$field]??[],$settings[$field]);
  $db->prepare('INSERT INTO byte_notion_sync(source_id,brand,settings) VALUES(?,?,?) ON DUPLICATE KEY UPDATE brand=VALUES(brand),settings=VALUES(settings),`cursor`=NULL,watermark=NULL,scan_started=NULL,next_run=0,enabled=1')->execute([$source,$brand,json_encode($settings,JSON_THROW_ON_ERROR)]);
  $db->prepare('DELETE FROM byte_notion_editor_jobs WHERE source_id=?')->execute([$source]);
  out(['message'=>'Automatic one-way sync enabled for '.$brand.'. Matching assignments will appear in My briefs while users are signed in.']);
 }
 if($action==='notion-auto-status'){if(!in_array($u['role'],['Head','Team leader'],true))fail('Team leader access required.',403);$sources=$db->query('SELECT source_id,brand,enabled,last_message FROM byte_notion_sync')->fetchAll();if($u['role']==='Team leader')foreach($sources as &$source)$source['last_message']='Shared source enabled; only your team assignments are shown in your preview.';out(['sources'=>$sources]);}
 if($action==='notion-auto-disable'){if($u['role']!=='Head')fail('Head access required.',403);$db->prepare('UPDATE byte_notion_sync SET enabled=0 WHERE source_id=?')->execute([(string)($input['source']??'')]);out(['message'=>'Automatic sync paused for this data source.']);}
 if($action!=='notion-auto-pull')fail('Unknown sync action.');
 if(!is_file(__DIR__.'/notion-config.php'))out(['message'=>'Automatic Notion sync is not configured.']);
 $personal=false;$personalIds=[];$row=null;
 if($u['role']==='Editor'){
  $allAccounts=$db->query("SELECT name,username,team FROM byte_users WHERE active=1 AND role='Editor'")->fetchAll();
  foreach($db->query('SELECT * FROM byte_notion_sync WHERE enabled=1 ORDER BY source_id')->fetchAll() as $candidate){
   $set=json_decode($candidate['settings'],true,512,JSON_THROW_ON_ERROR);$ids=[];foreach($set['notionPeople']??[] as $name=>$notionIds){$match=notionAccountMatch($name,$allAccounts,$set['editorAliases']??[]);if($match&&$match['name']===$u['name'])$ids=array_merge($ids,$notionIds);}
   if(!$ids)continue;$db->prepare('INSERT IGNORE INTO byte_notion_editor_jobs(source_id,user_id) VALUES(?,?)')->execute([$candidate['source_id'],$u['id']]);$q=$db->prepare('SELECT * FROM byte_notion_editor_jobs WHERE source_id=? AND user_id=?');$q->execute([$candidate['source_id'],$u['id']]);$job=$q->fetch();if((int)$job['next_run']>time())continue;
   if(!$row||(int)$job['next_run']<(int)$row['next_run']){$row=array_merge($candidate,$job);$personal=true;$personalIds=array_values(array_unique($ids));}
  }
 }
 if(!$row)$row=$db->query('SELECT * FROM byte_notion_sync WHERE enabled=1 AND next_run<='.time().' ORDER BY next_run,source_id LIMIT 1')->fetch();if(!$row)out(['message'=>'Waiting for next check. If no briefs appear, Head must save the assignee bindings and enable automatic sync for the correct source.']);
 $lease=bin2hex(random_bytes(4));$claimed=time()+120;if($personal){$q=$db->prepare('UPDATE byte_notion_editor_jobs SET next_run=? WHERE source_id=? AND next_run=? AND user_id=?');$q->execute([$claimed,$row['source_id'],$row['next_run'],$u['id']]);}else{$q=$db->prepare('UPDATE byte_notion_sync SET next_run=? WHERE source_id=? AND next_run=? AND enabled=1');$q->execute([$claimed,$row['source_id'],$row['next_run']]);}if(!$q->rowCount())out(['message'=>'Sync already running.']);if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
 $config=require __DIR__.'/notion-config.php';if(empty($config['token'])||str_contains($config['token'],'PASTE_'))throw new RuntimeException('Notion token is not configured.');$settings=json_decode($row['settings'],true,512,JSON_THROW_ON_ERROR);$map=$settings['mapping'];$body=['page_size'=>2,'sorts'=>[['timestamp'=>'last_edited_time','direction'=>'descending']]];
 if($row['cursor'])$body['start_cursor']=$row['cursor'];$assignedFilter=notionAssignedFilter($map['editor'],$personal?$personalIds:[],$row['watermark']);if($assignedFilter)$body['filter']=$assignedFilter;
 $scan=$row['scan_started']?:gmdate('Y-m-d\TH:i:s\Z',time()-60);$query=notionCall($config,'data_sources/'.notionId($row['source_id']).'/query',$body);
 $accounts=$db->query("SELECT name,username,team FROM byte_users WHERE active=1 AND role='Editor'")->fetchAll();$byName=[];foreach($accounts as $a)$byName[notionKey($a['name'])]=$a;
 $changed=0;$skipped=0;$candidates=[];
 foreach($query['results']??[] as $page){if(($page['object']??'')!=='page'||!empty($page['archived'])||!empty($page['in_trash']))continue;
  try{$b=notionMapped($page,$map,$row['brand']);$account=notionAccountMatch($b['editor'],$accounts,$settings['editorAliases']??[]);$rawType=notionValue($page['properties'][$map['type']??'']??[]);$type=$settings['typeAliases'][notionKey($rawType)]??$b['type'];if(!$account||!$b['id']||strlen($b['id'])>80||!in_array($type,['Video','VideoShorter'],true)){$skipped++;continue;}
  $q=$db->query('SELECT data FROM byte_workspace WHERE id=1');$check=json_decode($q->fetchColumn(),true,512,JSON_THROW_ON_ERROR);$found=null;foreach($check['briefs'] as $old)if(($old['notionPageId']??'')===$page['id']){$found=$old;break;}if($found&&($found['notionEditedAt']??'')===($page['last_edited_time']??''))continue;
  $blocks=notionBlocks($config,$page['id']);$b=array_merge(['title'=>'','content'=>'','blocks'=>[],'comments'=>[],'customProperties'=>[],'followers'=>[],'versions'=>[]],$b,['editor'=>$account['name'],'team'=>$account['team'],'type'=>$type,'approvalStatus'=>'Not submitted','notion'=>$page['url']??'','notionPageId'=>$page['id'],'notionEditedAt'=>$page['last_edited_time']??'','createdBy'=>'Notion import','createdAt'=>gmdate('c'),'updatedAt'=>gmdate('c'),'updatedBy'=>'Notion sync','blocks'=>$blocks,'content'=>implode("\n\n",array_column($blocks,'text'))]);$candidates[]=$b;
  }catch(RuntimeException $e){if($e instanceof PDOException)throw $e;$skipped++;}
 }
 $db->beginTransaction();$q=$db->query('SELECT data FROM byte_workspace WHERE id=1 FOR UPDATE');$data=json_decode($q->fetchColumn(),true,512,JSON_THROW_ON_ERROR);$before=$data;
 foreach($candidates as $b){$index=null;$duplicate=false;foreach($data['briefs'] as $i=>$old){if(($old['notionPageId']??'')===$b['notionPageId']){$index=$i;break;}if(strcasecmp($old['id'],$b['id'])===0)$duplicate=true;}
 if($index===null){if($duplicate){$skipped++;continue;}$b['notionBaseline']=notionBaselineFor($b);$b['notionLatestContent']=$b['content'];$data['briefs'][]=$b;$changed++;}
 else{$old=$data['briefs'][$index];$locked=false;foreach($data['invoices'] as $invoice)if(in_array($old['id'],$invoice['ids'],true))$locked=true;if($locked||!empty($old['trashedAt'])||!empty($old['archivedAt']))continue;$merged=notionMerge($old,$b);$merged['notionEditedAt']=$b['notionEditedAt'];$merged['updatedAt']=gmdate('c');$merged['updatedBy']='Notion sync';$data['briefs'][$index]=$merged;$changed++;}}
 if($changed){$json=json_encode($data,JSON_THROW_ON_ERROR);if(strlen($json)>1800000)throw new RuntimeException('Workspace size limit reached. Automatic import paused until reviewed.');$db->prepare('UPDATE byte_workspace SET data=?,revision=revision+1 WHERE id=1')->execute([$json]);}$db->commit();
 $more=!empty($query['has_more']);$message=$changed.' brief(s) added/refreshed; '.$skipped.' skipped (check assignee/type/brand mappings or large content).';$sql='UPDATE '.($personal?'byte_notion_editor_jobs':'byte_notion_sync').' SET `cursor`=?,watermark=?,scan_started=?,next_run=?,last_message=? WHERE source_id=? AND next_run=?'.($personal?' AND user_id=?':'');$params=[$more?($query['next_cursor']??null):null,$more?$row['watermark']:$scan,$more?$scan:null,time()+30,$message,$row['source_id'],$claimed];if($personal)$params[]=$u['id'];$db->prepare($sql)->execute($params);if($changed){try{$pushUsers=$db->query('SELECT id,name,role,team,active FROM byte_users WHERE active=1')->fetchAll();pushSend($db,pushRecipients($before,$data,$pushUsers,0));}catch(Throwable $ignored){}}out(['message'=>($personal?'Your assigned Notion briefs: ':'Notion source scan: ').$changed.' added/refreshed, '.$skipped.' skipped.'.($more?' More pages remain; scanning continues.':''),'changed'=>$changed]);
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();if(isset($row['source_id'],$claimed)){try{$sql='UPDATE '.(!empty($personal)?'byte_notion_editor_jobs':'byte_notion_sync').' SET next_run=?,last_message=? WHERE source_id=? AND next_run=?'.(!empty($personal)?' AND user_id=?':'');$params=[time()+60,'Sync failed. Recheck token, access, mappings, or workspace size.',$row['source_id'],$claimed];if(!empty($personal))$params[]=$u['id'];$db->prepare($sql)->execute($params);}catch(Throwable $ignored){}}if($e instanceof PDOException){$state=(string)$e->getCode();$driver=(int)($e->errorInfo[1]??0);error_log('Byte Co Notion sync database failure: SQLSTATE '.$state.' driver '.$driver);fail('Notion sync database error (SQLSTATE '.$state.', code '.$driver.'). Existing workspace data was not reset. Send this code for diagnosis; do not run installation.',503);}if(get_class($e)===RuntimeException::class)fail($e->getMessage(),400);fail('Automatic Notion sync could not complete.',500);}
}

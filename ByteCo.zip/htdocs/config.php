<?php
return [
    'host' => 'sql302.infinityfree.com',
    'database' => 'if0_43424994_byteco',
    'username' => 'if0_43424994',
    'password' => 'dabiidrystan01'
];
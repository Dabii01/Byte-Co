<?php
declare(strict_types=1);
function notionAccountMatch(string $source,array $accounts,array $bindings=[]):?array{
 $keyfn=fn($v)=>strtolower(trim(preg_replace('/\s+/u',' ',(string)$v)));$key=$keyfn($source);
 $aliases=['abegail barbon'=>['Abegail Barbon','Abegail'],'paui'=>['paui','sleepypaui','Paulina Lacerna','Paulina'],'zach'=>['Zach'],'chloe alistado'=>['Chloe Alistado','Chloe'],'dabii'=>['Dabii']];
 // Temporarily excluded even when older saved bindings still exist.
 if(in_array($key,['william melchor calibugar','william','ashlee apao','ashlee','melene'],true))return null;
 $exact=function($values)use($accounts,$keyfn){return array_values(array_filter($accounts,function($a)use($values,$keyfn){foreach($values as $v)if($keyfn($a['name'])===$keyfn($v)||(!empty($a['username'])&&$keyfn($a['username'])===$keyfn($v)))return true;return false;}));};
 if(isset($bindings[$key])){$found=$exact([$bindings[$key]]);return count($found)===1?$found[0]:null;}
 $found=$exact([$source]);if($found)return count($found)===1?$found[0]:null;
 if(!isset($aliases[$key]))return null;$names=$aliases[$key];$found=$exact($names);if($found)return count($found)===1?$found[0]:null;
 $first=[];foreach($names as $name)if(!str_contains($name,' ')&&strlen($name)>=4)$first[]=$keyfn($name);$found=array_values(array_filter($accounts,fn($a)=>in_array(explode(' ',$keyfn($a['name']))[0],$first,true)));return count($found)===1?$found[0]:null;
}
function notionId(string $s):string{$s=str_replace('-','',$s);if(!preg_match('/^[a-f0-9]{32}$/i',$s))throw new RuntimeException('Invalid Notion database or page ID in notion-config.php.');return $s;}
function notionReadPath(string $path,bool $query):bool{
 return $query?(bool)preg_match('~^data_sources/[a-f0-9-]{32,36}/query$~i',$path):(bool)preg_match('~^(?:databases/[a-f0-9-]{32,36}|data_sources/[a-f0-9-]{32,36}|blocks/[a-f0-9-]{32,36}/children(?:\?page_size=100(?:&start_cursor=[a-zA-Z0-9%._-]+)?)?)$~i',$path);
}
function notionCall(array $config,string $path,?array $body=null):array{
 if(!notionReadPath($path,$body!==null))throw new RuntimeException('Only read-only Notion requests are permitted.');
 if(!function_exists('curl_init'))throw new RuntimeException('PHP cURL is required for Notion.');
 usleep(350000);$ch=curl_init('https://api.notion.com/v1/'.$path);$options=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>15,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$config['token'],'Notion-Version: 2025-09-03','Content-Type: application/json']];if($body!==null){$options[CURLOPT_POST]=true;$options[CURLOPT_POSTFIELDS]=json_encode($body,JSON_THROW_ON_ERROR);}curl_setopt_array($ch,$options);$raw=curl_exec($ch);$errno=curl_errno($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
 if($errno)throw new RuntimeException('Notion connection failed: '.curl_strerror($errno));$data=json_decode((string)$raw,true);if($status<200||$status>=300||!is_array($data)){throw new RuntimeException(match($status){401=>'Notion rejected the token. Check notion-config.php.',403=>'Notion denied access. Check Dabi connection permissions.',404=>'Notion could not find this database. Check the original database ID and Dabi access.',429=>'Notion rate limit reached. Wait a minute and retry.',default=>'Notion returned HTTP '.$status.'. Check the configuration and retry.'});}return $data;
}
function notionText(array $rich):string{return implode('',array_map(fn($r)=>(string)($r['plain_text']??$r['text']['content']??''),$rich));}
function notionValue(array $p):string{
 $type=$p['type']??'';return match($type){'title','rich_text'=>notionText($p[$type]??[]),'select','status'=>(string)($p[$type]['name']??''),'multi_select'=>implode(', ',array_column($p[$type]??[],'name')),'people'=>implode(', ',array_column($p[$type]??[],'name')),'date'=>(string)($p['date']['start']??''),'url','email','phone_number'=>(string)($p[$type]??''),'number'=>isset($p['number'])?(string)$p['number']:'','checkbox'=>!empty($p['checkbox'])?'Yes':'No','formula'=>notionValue($p['formula']??[]),'string'=>(string)($p['string']??''),'unique_id'=>(string)($p['unique_id']['prefix']??'').(isset($p['unique_id']['number'])?'-'.$p['unique_id']['number']:''),default=>''};
}
function notionSuggest(array $properties):array{
 $aliases=['brand'=>['Brand'],'id'=>['Concept ID','Name','Title'],'status'=>['Status'],'product'=>['Product'],'format'=>['Format'],'editor'=>['Assignee','Editor'],'strategist'=>['Creative Strategist'],'type'=>['Type'],'persona'=>['Persona'],'problem'=>['Problem'],'link'=>['Review Link','Review'],'finalLink'=>['Final Link'],'naming'=>['Final Naming','Final Filename'],'due'=>['Due Date','Deadline'],'delivery'=>['Delivery Date'],'awareness'=>['Awareness Stage'],'mechanism'=>['Mechanism'],'winner'=>['Winner/Iterate'],'adResult'=>['Ad Result'],'progress'=>['Progress %','Progress']];$map=[];
 foreach($aliases as $field=>$names){$map[$field]='';foreach($names as $name)foreach($properties as $key=>$value)if(strcasecmp(trim($key),$name)===0){$map[$field]=$key;break 2;}}
 if(!$map['id'])foreach($properties as $key=>$value)if(($value['type']??'')==='title'){$map['id']=$key;break;}return $map;
}
function notionMapped(array $page,array $map,string $brand):array{
 $b=['id'=>'','status'=>'Ready for Production','product'=>'','format'=>'','editor'=>'','strategist'=>'','type'=>'','persona'=>'','problem'=>'','link'=>'','finalLink'=>'','naming'=>'','due'=>'','delivery'=>'','awareness'=>'','mechanism'=>'','winner'=>'','adResult'=>'','progress'=>0];foreach($b as $field=>$default){$name=$map[$field]??'';if($name!==''&&isset($page['properties'][$name]))$b[$field]=notionValue($page['properties'][$name]);}
 $brandProperty=$map['brand']??'';$sourceBrand=$brandProperty!==''&&isset($page['properties'][$brandProperty])?trim(notionValue($page['properties'][$brandProperty])):'';if($sourceBrand!==''&&strcasecmp($sourceBrand,$brand)!==0)throw new RuntimeException('This Notion row belongs to '.$sourceBrand.'. Select the matching brand before importing.');
 $b['id']=trim((string)$b['id']);$rawType=strtolower(trim((string)$b['type']));$b['type']=in_array($rawType,['video','long video'],true)?'Video':(in_array($rawType,['videoshorter','video shorter','short video'],true)?'VideoShorter':'');
 $rawStatus=preg_replace('/^\s*\d+[.\s-]+/','',trim((string)$b['status']));$b['status']=strcasecmp($rawStatus,'To produce')===0?'Ready for Production':($rawStatus?:'Ready for Production');$b['brand']=$brand;if($brand==='Allaura')$b['product']='';$progress=(float)$b['progress'];$b['progress']=max(0,min(100,(int)round($progress>0&&$progress<1?$progress*100:$progress)));foreach(['due','delivery'] as $field)$b[$field]=substr((string)$b[$field],0,10);
 foreach(['link','finalLink'] as $field)if(!validReviewUrl($b[$field]))$b[$field]='';return $b;
}
function notionSources(array $config,string $brand):array{
 $id=notionId((string)$config['sources'][$brand]);try{$database=notionCall($config,'databases/'.$id);$sources=$database['data_sources']??[];if($sources)return $sources;}catch(RuntimeException $e){if(!str_contains($e->getMessage(),'could not find'))throw $e;}
 // A shared brand page may contain one or more original child databases.
 $cursor=null;$sources=[];$count=0;do{$path='blocks/'.$id.'/children?page_size=100'.($cursor?'&start_cursor='.rawurlencode($cursor):'');$children=notionCall($config,$path);foreach($children['results']??[] as $block)if(($block['type']??'')==='child_database'){$db=notionCall($config,'databases/'.notionId($block['id']));foreach($db['data_sources']??[] as $ds)$sources[]=$ds;}$cursor=$children['next_cursor']??null;$count++;}while(!empty($children['has_more'])&&$count<5);
 if(!$sources)throw new RuntimeException('This link is a page or linked view, and no original child database was found. Ask the owner for the original database link and put its ID in notion-config.php.');return $sources;
}
function notionBlocks(array $config,string $id,int $depth=0,?array &$budget=null):array{
 if($budget===null)$budget=['requests'=>0,'blocks'=>0,'started'=>microtime(true)];$cursor=null;$out=[];do{
 if(++$budget['requests']>20||microtime(true)-$budget['started']>18)throw new RuntimeException('This brief is too large for one import request. No brief was saved. Import its content manually using the Notion link.');
 $r=notionCall($config,'blocks/'.notionId($id).'/children?page_size=100'.($cursor?'&start_cursor='.rawurlencode($cursor):''));
 foreach($r['results']??[] as $block){if(++$budget['blocks']>1000)throw new RuntimeException('This brief has over 1,000 blocks. No brief was saved.');$type=$block['type']??'';$value=$block[$type]??[];$text=notionText($value['rich_text']??$value['caption']??[]);$kind=match($type){'heading_1'=>'heading','heading_2'=>'heading2','heading_3'=>'heading3','bulleted_list_item'=>'bullet','numbered_list_item'=>'numbered','to_do'=>'todo','quote'=>'quote','toggle'=>'toggle','divider'=>'divider','callout'=>'callout',default=>'paragraph'};
 if($type==='table_row')$text=implode(' | ',array_map('notionText',$value['cells']??[]));if(in_array($type,['image','video','audio','file','pdf'],true)){$url=$value[$value['type']??'external']['url']??'';$text=trim($text."\n".'['.$type.'] '.$url);}if(in_array($type,['bookmark','link_preview','embed'],true))$text=trim($text."\n".($value['url']??''));if($type==='child_page')$text='[Page] '.($value['title']??'');if($type==='equation')$text=(string)($value['expression']??'');if($text===''&&!in_array($type,['paragraph','heading_1','heading_2','heading_3','divider','table'],true))$text='[Notion '.$type.' block — see original page]';if($type==='unsupported')$text='[Unsupported Notion block — see original page]';
 $out[]=['id'=>'notion-'.str_replace('-','',$block['id']),'kind'=>$kind,'text'=>$text,'checked'=>(bool)($value['checked']??false)];if(!empty($block['has_children'])){if($depth>=8)throw new RuntimeException('Nested content exceeds the import depth limit. No brief was saved.');$out=array_merge($out,notionBlocks($config,$block['id'],$depth+1,$budget));}}
 $cursor=$r['next_cursor']??null;}while(!empty($r['has_more']));return $out;
}
function handleNotion(PDO $db,array $u,string $action,string $method,array $input):never{
 if(!in_array($u['role'],['Head','Team leader'],true))fail('Only Head and team leaders can preview/import Notion briefs.',403);if($method!=='POST')fail('Method not allowed.',405);
 try{
 if(!is_file(__DIR__.'/notion-config.php'))throw new RuntimeException('Copy notion-config.example.php to notion-config.php and enter your Notion token there. Keep config.php unchanged.');$config=require __DIR__.'/notion-config.php';if(!is_string($config['token']??null)||!$config['token']||str_contains($config['token'],'PASTE_')||preg_match('/[\r\n]/',$config['token']))throw new RuntimeException('Enter a valid token in notion-config.php.');
 $brand=(string)($input['brand']??'');if(!in_array($brand,['The Fleece Company','Allaura'],true)||!isset($config['sources'][$brand]))fail('Choose a configured brand.');
 if($action==='notion-test'){$sources=notionSources($config,$brand);$_SESSION['notion_sources'][$brand]=$sources;out(['sources'=>$sources,'message'=>'Connection successful. Choose the data source, then preview.']);}
 $source=(string)($input['source']??'');$allowed=array_column($_SESSION['notion_sources'][$brand]??[],'id');if(!in_array($source,$allowed,true))fail('Run Test connection and choose a data source first.');
 if($action==='notion-preview'){
 $cursor=$input['cursor']??null;if($cursor!==null&&(!is_string($cursor)||strlen($cursor)>500))fail('Invalid cursor.');$body=['page_size'=>25,'sorts'=>[['timestamp'=>'last_edited_time','direction'=>'descending']]];if($cursor)$body['start_cursor']=$cursor;
 $query=notionCall($config,'data_sources/'.notionId($source).'/query',$body);$pages=array_values(array_filter($query['results']??[],fn($p)=>($p['object']??'')==='page'&&empty($p['archived'])&&empty($p['in_trash'])));$schema=notionCall($config,'data_sources/'.notionId($source));
 $bindings=[];$saved=[];if($db->query("SHOW TABLES LIKE 'byte_notion_sync'")->fetchColumn()){$q=$db->prepare('SELECT settings FROM byte_notion_sync WHERE source_id=?');$q->execute([$source]);$saved=json_decode($q->fetchColumn()?:'{}',true);$bindings=$saved['editorAliases']??[];}
 $suggested=$saved['mapping']??notionSuggest($schema['properties']??[]);
 if($u['role']==='Team leader'){
  $accounts=$db->query("SELECT name,username,team FROM byte_users WHERE active=1 AND role='Editor'")->fetchAll();
  $pages=array_values(array_filter($pages,function($page)use($u,$accounts,$bindings,$suggested){$raw=notionValue($page['properties'][$suggested['editor']??'']??[]);$match=notionAccountMatch($raw,$accounts,$bindings);return $match&&$match['team']===$u['team'];}));
  $ownNames=array_column(array_values(array_filter($accounts,fn($a)=>$a['team']===$u['team'])),'name');$bindings=array_filter($bindings,fn($name)=>in_array($name,$ownNames,true));
 }
 $batch=bin2hex(random_bytes(16));$_SESSION['notion_preview']=['batch'=>$batch,'brand'=>$brand,'source'=>$source,'pages'=>array_column($pages,null,'id'),'expires'=>time()+3600];
 $rows=[];foreach($pages as $page){$values=[];foreach($page['properties']??[] as $key=>$prop)$values[$key]=notionValue($prop);$rows[]=['pageId'=>$page['id'],'values'=>$values,'url'=>$page['url']??''];}
 out(['bindings'=>(object)$bindings,'batch'=>$batch,'rows'=>$rows,'suggested'=>$suggested,'properties'=>array_keys($schema['properties']??[]),'nextCursor'=>!empty($query['has_more'])?($query['next_cursor']??null):null]);
 }
 if($action!=='notion-import')fail('Unknown Notion action.');$preview=$_SESSION['notion_preview']??[];if(($preview['expires']??0)<time()||!hash_equals($preview['batch']??'',(string)($input['batch']??''))||($preview['brand']??'')!==$brand||($preview['source']??'')!==$source)fail('Preview expired. Load it again.');
 $pageId=(string)($input['pageId']??'');$page=$preview['pages'][$pageId]??null;if(!$page)fail('Select a page from the current preview.');$map=$input['mapping']??null;if(!is_array($map)||count($map)>25)fail('Invalid field mapping.');foreach($map as $field=>$property)if(!is_string($property)||($property!==''&&!isset($page['properties'][$property])))fail('Invalid mapped property.');
 $b=notionMapped($page,$map,$brand);$editor=(string)($input['editor']??'');$type=(string)($input['type']??'');if(!in_array($type,['Video','VideoShorter'],true))fail('Choose Video or VideoShorter for the imported brief.');$q=$db->prepare("SELECT name,team FROM byte_users WHERE name=? AND role='Editor' AND active=1");$q->execute([$editor]);$account=$q->fetch();if(!$account)fail('Choose an active Byte Co. Editor account.');if($u['role']==='Team leader'&&$account['team']!==$u['team'])fail('You can only import briefs for your own team.',403);if(!$b['id']||strlen($b['id'])>80)fail('Concept ID must contain 1–80 characters. Check the field mapping.');
 // Avoid fetching a duplicate's content or touching existing records.
 $q=$db->query('SELECT data FROM byte_workspace WHERE id=1');$existing=json_decode($q->fetchColumn(),true,512,JSON_THROW_ON_ERROR);foreach($existing['briefs'] as $old)if(strcasecmp($old['id'],$b['id'])===0||($old['notionPageId']??'')===$pageId)fail('Skipped: that Concept ID or Notion page already exists in Byte Co.',409);
 $blocks=notionBlocks($config,$pageId);$b=array_merge(['title'=>'','notion'=>'','content'=>'','blocks'=>[],'comments'=>[],'customProperties'=>[],'followers'=>[],'versions'=>[]],$b,['editor'=>$account['name'],'team'=>$account['team'],'type'=>$type,'approvalStatus'=>'Not submitted','notion'=>$page['url']??'','notionPageId'=>$pageId,'createdBy'=>$u['name'],'createdAt'=>gmdate('c'),'updatedAt'=>gmdate('c'),'updatedBy'=>$u['name'],'blocks'=>$blocks,'content'=>implode("\n\n",array_column($blocks,'text'))]);
 $extras=[];foreach($page['properties']??[] as $key=>$prop)if(!in_array($key,array_values($map),true)){$value=notionValue($prop);if($value!=='')$extras[]=['name'=>$key,'value'=>$value];}$b['customProperties']=$extras;
 $db->beginTransaction();$q=$db->query('SELECT data FROM byte_workspace WHERE id=1 FOR UPDATE');$data=json_decode($q->fetchColumn(),true,512,JSON_THROW_ON_ERROR);foreach($data['briefs'] as $old)if(strcasecmp($old['id'],$b['id'])===0||($old['notionPageId']??'')===$pageId){$db->rollBack();fail('Skipped: another import already added this brief.',409);}$data['briefs'][]=$b;$json=json_encode($data,JSON_THROW_ON_ERROR);if(strlen($json)>1800000){$db->rollBack();fail('Workspace is approaching its size limit. Nothing was imported.');}$db->prepare('UPDATE byte_workspace SET data=?,revision=revision+1 WHERE id=1')->execute([$json]);$db->commit();out(['message'=>'Imported '.$b['id'].' for '.$account['name'].'.','id'=>$b['id']]);
 }catch(RuntimeException $e){if($db->inTransaction())$db->rollBack();if($e instanceof PDOException)throw $e;fail($e->getMessage(),400);}
}

<?php
declare(strict_types=1);
function editableAccount(array $actor,array $old,array $input):array{
 if($actor['role']!=='Head')fail('Only Head can edit account details.',403);
 $next=['name'=>trim((string)($input['name']??'')),'email'=>strtolower(trim((string)($input['email']??''))),'username'=>trim((string)($input['username']??'')),'role'=>(string)($input['role']??''),'team'=>trim((string)($input['team']??''))];
 if(!$next['name']||strlen($next['name'])>100||!filter_var($next['email'],FILTER_VALIDATE_EMAIL)||strlen($next['email'])>190||!preg_match('/^[a-zA-Z0-9_.-]{3,100}$/',$next['username'])||!in_array($next['role'],['Head','Team leader','Editor'],true)||($next['role']!=='Head'&&!$next['team'])||strlen($next['team'])>100)fail('Check the name, email, username, role and team.');
 if((int)$actor['id']===(int)$old['id']&&$next['role']!=='Head')fail('You cannot remove the Head role from your own signed-in account.');
 if($next['role']==='Head')$next['team']='';return $next;
}
function migrateAccountWorkspace(array $data,array $old,array $next):array{
 $locked=[];foreach($data['invoices'] as $i)$locked=array_merge($locked,$i['ids']);
 if($old['team']!==$next['team'])foreach($data['briefs'] as $b)if($b['editor']===$old['name']&&in_array($b['id'],$locked,true))fail('This account has invoiced briefs. Keep its current team to preserve payment history.');
 foreach($data['briefs'] as &$b){if($b['editor']===$old['name']){$b['editor']=$next['name'];$b['team']=$next['team'];}}
 unset($b);
 if($old['name']!==$next['name']){
  $rename=function(&$value,$key=null)use(&$rename,$old,$next){if(is_array($value)){foreach($value as $k=>&$v){if($k==='followers'&&is_array($v))$v=array_map(fn($s)=>$s===$old['name']?$next['name']:$s,$v);else $rename($v,$k);}unset($v);}elseif(in_array($key,['editor','createdBy','updatedBy','reviewedBy','author'],true)&&$value===$old['name'])$value=$next['name'];};
  $rename($data);
 }
 return $data;
}
function editAccount(PDO $db,array $actor,array $input):never{
 if($actor['role']!=='Head')fail('Only Head can edit account details.',403);
 $id=(int)($input['id']??0);$db->beginTransaction();
 try{$q=$db->prepare('SELECT * FROM byte_users WHERE id=? FOR UPDATE');$q->execute([$id]);$old=$q->fetch();if(!$old){$db->rollBack();fail('Account not found.',404);}$next=editableAccount($actor,$old,$input);
 $q=$db->query('SELECT data FROM byte_workspace WHERE id=1 FOR UPDATE');$data=json_decode($q->fetchColumn(),true,512,JSON_THROW_ON_ERROR);$updated=migrateAccountWorkspace($data,$old,$next);
 $db->prepare('UPDATE byte_users SET name=?,email=?,username=?,role=?,team=?,session_version=session_version+1 WHERE id=?')->execute([$next['name'],$next['email'],$next['username'],$next['role'],$next['team'],$id]);
 if($updated!=$data)$db->prepare('UPDATE byte_workspace SET data=?,revision=revision+1 WHERE id=1')->execute([json_encode($updated,JSON_THROW_ON_ERROR)]);
 if($old['name']!==$next['name']&&$db->query("SHOW TABLES LIKE 'byte_notion_sync'")->fetchColumn()){
  foreach($db->query('SELECT source_id,settings FROM byte_notion_sync FOR UPDATE')->fetchAll() as $row){$settings=json_decode($row['settings'],true,512,JSON_THROW_ON_ERROR);foreach($settings['editorAliases']??[] as $key=>$name)if($name===$old['name'])$settings['editorAliases'][$key]=$next['name'];$key=strtolower(trim(preg_replace('/\s+/u',' ',$old['name'])));$settings['editorAliases'][$key]=$next['name'];$db->prepare('UPDATE byte_notion_sync SET settings=? WHERE source_id=?')->execute([json_encode($settings,JSON_THROW_ON_ERROR),$row['source_id']]);}
 }
 $db->commit();$q=$db->prepare('SELECT * FROM byte_users WHERE id=?');$q->execute([$id]);$saved=$q->fetch();if($id===(int)$actor['id']){$_SESSION['version']=(int)$saved['session_version'];$actor=$saved;}out(['ok'=>true,'user'=>cleanUser($actor)]);
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}

const diagnosticsCache='byte-push-diagnostics-v1';
const diagnosticsUrl=new URL('./__byte_push_last',self.registration.scope).href;
async function saveDiagnostic(value){try{const c=await caches.open(diagnosticsCache);await c.put(diagnosticsUrl,new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json'}}))}catch{}}
async function lastDiagnostic(){try{const c=await caches.open(diagnosticsCache);const r=await c.match(diagnosticsUrl);return r?await r.json():null}catch{return null}}
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('message',event=>{if(event.data?.type==='push-diagnostics')event.waitUntil((async()=>event.ports[0]?.postMessage({version:2,last:await lastDiagnostic()}))());});
self.addEventListener('push',event=>{const receivedAt=Date.now();event.waitUntil((async()=>{
 let displayError='';try{await self.registration.showNotification('Byte Co.',{body:'You have a new workspace update. Open Byte Co. to view your notifications.',icon:new URL('./byte-co-logo.png',self.registration.scope).href,tag:'byteco-'+receivedAt,renotify:true,data:{url:new URL('./',self.registration.scope).href}})}catch(e){displayError=String(e)}
 await saveDiagnostic({receivedAt,displayError});const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});for(const client of windows)client.postMessage({type:'byte-push-received',receivedAt,displayError});
})());});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil((async()=>{const url=new URL('./?notifications=1',self.registration.scope).href;const windows=await clients.matchAll({type:'window',includeUncontrolled:true});for(const client of windows){if(new URL(client.url).origin===self.location.origin){await client.navigate(url);return client.focus();}}return clients.openWindow(url)})());});

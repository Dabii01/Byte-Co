<?php
declare(strict_types=1);
function pushB64(string $s):string{return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
function pushEndpoint(string $url):bool {
 $p=parse_url($url);if(!$p||($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['fragment'])||isset($p['port'])||strlen($url)>2000)return false;
 $host=strtolower($p['host']??'');return in_array($host,['fcm.googleapis.com','updates.push.services.mozilla.com','push.services.mozilla.com','web.push.apple.com'],true)||str_ends_with($host,'.push.apple.com');
}
function pushSchema(PDO $db):void{
 $db->exec('CREATE TABLE IF NOT EXISTS byte_push_keys (id INT PRIMARY KEY,public_key TEXT NOT NULL,private_key TEXT NOT NULL)');
 $db->exec('CREATE TABLE IF NOT EXISTS byte_push_devices (endpoint_hash CHAR(64) PRIMARY KEY,user_id INT NOT NULL,endpoint TEXT NOT NULL,updated_at DATETIME NOT NULL,INDEX(user_id))');
}
function pushKeys(PDO $db):array {
 if(!extension_loaded('openssl')||!function_exists('curl_init'))throw new RuntimeException('Push needs PHP OpenSSL and cURL enabled on the host.');
 pushSchema($db);$keys=$db->query('SELECT * FROM byte_push_keys WHERE id=1')->fetch();if($keys)return $keys;
 $key=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);if(!$key||!openssl_pkey_export($key,$pem))throw new RuntimeException('The host could not create push signing keys.');
 $d=openssl_pkey_get_details($key);$public=pushB64("\x04".str_pad($d['ec']['x'],32,"\0",STR_PAD_LEFT).str_pad($d['ec']['y'],32,"\0",STR_PAD_LEFT));
 $db->prepare('INSERT IGNORE INTO byte_push_keys(id,public_key,private_key) VALUES(1,?,?)')->execute([$public,$pem]);return $db->query('SELECT * FROM byte_push_keys WHERE id=1')->fetch();
}
function pushRawSignature(string $der):string {
 // P-256 ECDSA DER SEQUENCE of two INTEGERs -> JOSE fixed-width r || s.
 if(strlen($der)<8||ord($der[0])!==48||ord($der[2])!==2)throw new RuntimeException('Invalid signing result.');
 $rlen=ord($der[3]);$r=substr($der,4,$rlen);$offset=4+$rlen;if(!isset($der[$offset+1])||ord($der[$offset])!==2)throw new RuntimeException('Invalid signing result.');
 $s=substr($der,$offset+2,ord($der[$offset+1]));$r=ltrim($r,"\0");$s=ltrim($s,"\0");if(strlen($r)>32||strlen($s)>32)throw new RuntimeException('Invalid signing result.');return str_pad($r,32,"\0",STR_PAD_LEFT).str_pad($s,32,"\0",STR_PAD_LEFT);
}
function pushAuthorization(string $endpoint,array $keys):string {
 $aud='https://'.parse_url($endpoint,PHP_URL_HOST);$header=pushB64('{"typ":"JWT","alg":"ES256"}');$claims=pushB64(json_encode(['aud'=>$aud,'exp'=>time()+3600,'sub'=>'https://byteco.ct.ws/'],JSON_THROW_ON_ERROR));$unsigned=$header.'.'.$claims;
 if(!openssl_sign($unsigned,$der,$keys['private_key'],OPENSSL_ALGO_SHA256))throw new RuntimeException('Push signing failed.');return 'vapid t='.$unsigned.'.'.pushB64(pushRawSignature($der)).', k='.$keys['public_key'];
}
function pushFailure(int $code,int $errno):string {
 if($errno!==0)return 'Connection error '.$errno.': '.curl_strerror($errno).'.';
 return match($code){
  0=>'No HTTP response from the browser push service.',
  400=>'HTTP 400: the push service rejected the request format.',
  401,403=>'HTTP '.$code.': the push service rejected the signing credentials. Disable push on this device, then enable it again and retry.',
  404,410=>'HTTP '.$code.': this device subscription has expired. Disable push, then enable it again.',
  429=>'HTTP 429: push service rate limit. Wait and retry.',
  default=>'HTTP '.$code.': push delivery was rejected.'
 };
}
function pushSend(PDO $db,array $userIds,?string $onlyEndpoint=null):array {
 $result=['sent'=>0,'failed'=>0,'devices'=>0,'errors'=>[]];if(!$userIds)return $result;
 try{$keys=pushKeys($db);$ids=array_values(array_unique(array_map('intval',$userIds)));$q=$db->prepare('SELECT d.* FROM byte_push_devices d JOIN byte_users u ON u.id=d.user_id WHERE u.active=1 AND d.user_id IN ('.implode(',',array_fill(0,count($ids),'?')).')');$q->execute($ids);$rows=$q->fetchAll();if($onlyEndpoint!==null)$rows=array_values(array_filter($rows,fn($row)=>hash_equals($onlyEndpoint,$row['endpoint'])));$result['devices']=count($rows);if(!$rows)$result['errors'][]='No registered device matches this browser and signed-in account. Disable push, then enable it again.';
 // Use standard cURL: some shared hosts disable curl_multi_* functions.
 foreach($rows as $row){
  if(!pushEndpoint($row['endpoint']))continue;
  $ch=curl_init($row['endpoint']);
  if(!$ch)throw new RuntimeException('The host could not initialize cURL.');
  $options=[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>'',CURLOPT_HTTPHEADER=>['TTL: 3600','Urgency: normal','Topic: byteco-updates','Content-Length: 0','Authorization: '.pushAuthorization($row['endpoint'],$keys)],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>6,CURLOPT_FOLLOWLOCATION=>false];
  if(defined('CURLOPT_PROTOCOLS')&&defined('CURLPROTO_HTTPS'))$options[CURLOPT_PROTOCOLS]=CURLPROTO_HTTPS;
  curl_setopt_array($ch,$options);curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
  if($code>=200&&$code<300)$result['sent']++;
  else{$result['failed']++;$result['errors'][]=pushFailure($code,curl_errno($ch));if(in_array($code,[404,410],true))$db->prepare('DELETE FROM byte_push_devices WHERE endpoint_hash=?')->execute([$row['endpoint_hash']]);}
  curl_close($ch);
 }
 }catch(Throwable $e){$result['failed']++;$result['errors'][]=get_class($e)===RuntimeException::class?$e->getMessage():(preg_match('/(?:Call to undefined function [a-zA-Z0-9_\\\\]+\(\)|Undefined constant \"[a-zA-Z0-9_\\\\]+\")/',$e->getMessage(),$match)?'Host PHP error: '.$match[0]:'Push failed during server setup or delivery. PHP error class: '.get_class($e));error_log('Byte Co push delivery could not complete: '.get_class($e));}return $result;
}
function pushRecipients(array $before,array $after,array $users,int $actor):array {
 $ids=[];$oldBriefs=array_column($before['briefs'],null,'id');$oldInvoices=array_column($before['invoices'],null,'id');
 foreach($after['briefs'] as $b){$old=$oldBriefs[$b['id']]??null;foreach($users as $u){if((int)$u['id']===$actor||!$u['active'])continue;$role=$u['role'];$sameTeam=$u['team']===$b['team'];$state=$b['approvalStatus']??'Not submitted';$prior=$old['approvalStatus']??'Not submitted';
 $assigned=$role==='Editor'&&$u['name']===$b['editor']&&(!$old||$old['editor']!==$b['editor']);
 $review=$role==='Team leader'&&$sameTeam&&$state==='Pending review'&&($prior!==$state||($old['submittedAt']??'')!==($b['submittedAt']??''));
 $decision=$role==='Editor'&&$u['name']===$b['editor']&&in_array($state,['Approved','Changes requested'],true)&&($prior!==$state||($old['reviewedAt']??'')!==($b['reviewedAt']??''));
 $follower=$role==='Editor'?$u['name']:($role==='Team leader'?$u['team'].' · Team leader':'Head');$canSee=$role==='Head'||($role==='Team leader'&&$sameTeam)||($role==='Editor'&&$u['name']===$b['editor']);
 $follow=$canSee&&in_array($follower,$b['followers']??[],true)&&($old['updatedAt']??'')!==($b['updatedAt']??'');if($assigned||$review||$decision||$follow)$ids[]=(int)$u['id'];}}
 foreach($after['invoices'] as $i){$old=$oldInvoices[$i['id']]??null;if($old&&$old['status']===$i['status'])continue;foreach($users as $u){if((int)$u['id']===$actor||!$u['active'])continue;$relevant=$u['role']==='Head'||($u['role']==='Team leader'&&$u['team']===$i['team']);if($u['role']==='Editor'&&$u['team']===$i['team'])foreach($after['briefs'] as $b)if(in_array($b['id'],$i['ids'],true)&&$b['editor']===$u['name'])$relevant=true;if($relevant)$ids[]=(int)$u['id'];}}
 return array_values(array_unique($ids));
}
